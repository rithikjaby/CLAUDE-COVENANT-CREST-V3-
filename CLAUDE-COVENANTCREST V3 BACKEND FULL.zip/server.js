/**
 * server.js — Covenant Crest Group Ltd Backend API
 * =======================================================
 * Express + JSON file-store backend. No database required.
 * Serves REST endpoints consumed by recruitment.html (/api/jobs)
 * and the admin dashboard (future API-backed admin panel).
 *
 * DEPLOY TO: Render.com (free tier)
 *   1. Push this file to a GitHub repo
 *   2. Create a new Web Service on Render, connect the repo
 *   3. Build command: npm install
 *   4. Start command: node server.js
 *   5. Add environment variables (see CONFIGURATION below)
 *   6. Uncomment the API proxy block in netlify.toml
 *
 * LOCAL DEV:
 *   npm install express cors
 *   node server.js
 *   → http://localhost:3001
 *
 * =======================================================
 * ROLES
 *   superadmin  — full access (set SUPER_ADMIN_EMAIL + SUPER_ADMIN_PWD in env)
 *   employee    — manage jobs + view contacts only
 * =======================================================
 */

'use strict';

const express  = require('express');
const cors     = require('cors');
const fs       = require('fs');
const path     = require('path');
const crypto   = require('crypto');

const app  = express();
const PORT = process.env.PORT || 3001;

// ───────────────────────────────────────────────
// CONFIGURATION (set as environment variables on Render)
// ───────────────────────────────────────────────
const SUPER_ADMIN_EMAIL = process.env.SUPER_ADMIN_EMAIL || 'admin@covenantcrest.co.uk';
const SUPER_ADMIN_PWD   = process.env.SUPER_ADMIN_PWD   || 'covenant2025';
const JWT_SECRET        = process.env.JWT_SECRET        || 'change-me-in-production-' + Math.random();
const ALLOWED_ORIGIN    = process.env.ALLOWED_ORIGIN    || 'https://covenantcrest.co.uk';

// ───────────────────────────────────────────────
// DATA DIRECTORY & FILE PATHS
// ───────────────────────────────────────────────
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const JOBS_FILE     = path.join(DATA_DIR, 'jobs.json');
const CONTACTS_FILE = path.join(DATA_DIR, 'contacts.json');
const USERS_FILE    = path.join(DATA_DIR, 'users.json');

// ───────────────────────────────────────────────
// HELPERS — JSON FILE STORE
// ───────────────────────────────────────────────
function readFile(filePath, defaultVal = []) {
  try {
    if (!fs.existsSync(filePath)) return defaultVal;
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (e) {
    console.error('readFile error:', filePath, e.message);
    return defaultVal;
  }
}

function writeFile(filePath, data) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (e) {
    console.error('writeFile error:', filePath, e.message);
    return false;
  }
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

// ───────────────────────────────────────────────
// SEED DEFAULT JOBS
// ───────────────────────────────────────────────
function seedDefaultJobs() {
  const jobs = readFile(JOBS_FILE);
  if (jobs.length > 0) return;
  const defaults = [
    { id: uid(), title: 'Care Assistant', sector: 'care', type: 'full-time', location: 'Telford', pay: '£11.44–12.50/hr', desc: 'Compassionate care assistant needed in Telford to support elderly residents with daily living, personal care and companionship.', req: 'Enhanced DBS required. Experience preferred but not essential. Full training provided.', status: 'active', posted: new Date().toISOString() },
    { id: uid(), title: 'Night Care Worker', sector: 'care', type: 'full-time', location: 'Telford', pay: '£12.00–13.50/hr', desc: 'Night shift care worker required for a residential care home in Telford. Overnight personal care, medication and safety monitoring.', req: 'Enhanced DBS. Night working experience preferred.', status: 'active', posted: new Date().toISOString() },
    { id: uid(), title: 'SIA Door Supervisor', sector: 'security', type: 'full-time', location: 'Birmingham', pay: '£13.00–15.00/hr', desc: 'Licensed Door Supervisor required for various Birmingham city centre venues. Day and night shifts available.', req: 'Valid SIA Door Supervisor licence mandatory. Minimum 1 year experience.', status: 'active', posted: new Date().toISOString() },
    { id: uid(), title: 'Retail Security Officer', sector: 'security', type: 'part-time', location: 'Wolverhampton', pay: '£11.44–12.50/hr', desc: 'Retail security officer for a busy retail park in Wolverhampton. Loss prevention, customer service and maintaining a safe environment.', req: 'SIA licence preferred. Smart appearance, good communication skills.', status: 'active', posted: new Date().toISOString() },
    { id: uid(), title: 'Warehouse Operative', sector: 'warehouse', type: 'temporary', location: 'Telford', pay: '£11.44/hr', desc: 'Warehouse operatives required immediately for a busy distribution centre in Telford. Picking, packing, goods-in and despatch.', req: 'No experience necessary. Steel-toed boots required.', status: 'active', posted: new Date().toISOString() },
    { id: uid(), title: 'FLT Driver', sector: 'warehouse', type: 'permanent', location: 'Shrewsbury', pay: '£13.00–14.50/hr', desc: 'Experienced forklift truck driver required for a manufacturing site in Shrewsbury. Counter-balance and reach truck.', req: 'Valid FLT licence (counter-balance essential). 2+ years experience.', status: 'active', posted: new Date().toISOString() },
  ];
  writeFile(JOBS_FILE, defaults);
  console.log('✅ Seeded', defaults.length, 'default jobs');
}
seedDefaultJobs();

// ───────────────────────────────────────────────
// SIMPLE JWT (no external library needed)
// ───────────────────────────────────────────────
function base64url(data) {
  return Buffer.from(JSON.stringify(data)).toString('base64url');
}

function makeToken(payload) {
  const header  = base64url({ alg: 'HS256', typ: 'JWT' });
  const body    = base64url({ ...payload, iat: Math.floor(Date.now() / 1000), exp: Math.floor(Date.now() / 1000) + 86400 * 7 }); // 7 days
  const sig     = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${sig}`;
}

function verifyToken(token) {
  if (!token) return null;
  try {
    const [header, body, sig] = token.split('.');
    const expected = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest('base64url');
    if (sig !== expected) return null;
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
    if (payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch (e) {
    return null;
  }
}

// ───────────────────────────────────────────────
// MIDDLEWARE
// ───────────────────────────────────────────────
app.use(cors({
  origin: function (origin, callback) {
    // Allow requests with no origin (e.g. Postman, server-to-server) or matching allowed origin
    const allowed = [ALLOWED_ORIGIN, 'http://localhost:3000', 'http://localhost:5500', 'http://127.0.0.1:5500'];
    if (!origin || allowed.includes(origin)) return callback(null, true);
    callback(new Error('Not allowed by CORS'));
  },
  credentials: true,
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ───────────────────────────────────────────────
// AUTH MIDDLEWARE
// ───────────────────────────────────────────────
function requireAuth(req, res, next) {
  const authHeader = req.headers['authorization'] || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  const payload = verifyToken(token);
  if (!payload) return res.status(401).json({ error: 'Unauthorised. Please log in.' });
  req.user = payload;
  next();
}

function requireSuperAdmin(req, res, next) {
  requireAuth(req, res, function () {
    if (req.user.role !== 'superadmin') {
      return res.status(403).json({ error: 'Forbidden. Super Admin access required.' });
    }
    next();
  });
}

// ───────────────────────────────────────────────
// HEALTH CHECK
// ───────────────────────────────────────────────
app.get('/', (req, res) => res.json({
  status: 'ok',
  service: 'Covenant Crest API',
  version: '1.0.0',
  timestamp: new Date().toISOString(),
}));

app.get('/health', (req, res) => res.json({ status: 'healthy' }));

// ───────────────────────────────────────────────
// AUTH ROUTES
// ───────────────────────────────────────────────

/**
 * POST /api/auth/login
 * Body: { email, password }
 * Returns: { token, role, email }
 */
app.post('/api/auth/login', (req, res) => {
  const { email = '', password = '' } = req.body;
  const emailLc = email.trim().toLowerCase();

  // Check Super Admin
  if (emailLc === SUPER_ADMIN_EMAIL.toLowerCase() && password === SUPER_ADMIN_PWD) {
    const token = makeToken({ email: emailLc, role: 'superadmin' });
    return res.json({ token, role: 'superadmin', email: emailLc });
  }

  // Check Employees
  const users = readFile(USERS_FILE);
  const user = users.find(u => u.email.toLowerCase() === emailLc && u.password === password && u.role === 'employee');
  if (user) {
    const token = makeToken({ email: user.email, role: 'employee', id: user.id });
    return res.json({ token, role: 'employee', email: user.email });
  }

  return res.status(401).json({ error: 'Invalid email or password.' });
});

/**
 * GET /api/auth/me
 * Returns current user info from token
 */
app.get('/api/auth/me', requireAuth, (req, res) => {
  res.json({ email: req.user.email, role: req.user.role });
});

// ───────────────────────────────────────────────
// JOBS ROUTES
// ───────────────────────────────────────────────

/**
 * GET /api/jobs
 * Public — returns active jobs only
 * Query params: sector, type, location (optional filters)
 */
app.get('/api/jobs', (req, res) => {
  let jobs = readFile(JOBS_FILE).filter(j => j.status === 'active');

  const { sector, type, location } = req.query;
  if (sector)   jobs = jobs.filter(j => j.sector   === sector);
  if (type)     jobs = jobs.filter(j => j.type     === type);
  if (location) jobs = jobs.filter(j => (j.location||'').toLowerCase().includes(location.toLowerCase()));

  // Don't expose internal fields to public
  const safeJobs = jobs.map(({ id, title, sector, type, location, pay, desc, req: requirements, posted }) => ({
    id, title, sector, type, location, pay, desc, req: requirements, posted,
  }));

  res.json(safeJobs);
});

/**
 * GET /api/jobs/all
 * Protected (any authenticated user) — returns all jobs including inactive
 */
app.get('/api/jobs/all', requireAuth, (req, res) => {
  res.json(readFile(JOBS_FILE));
});

/**
 * POST /api/jobs
 * Protected (any authenticated user) — create a new job
 */
app.post('/api/jobs', requireAuth, (req, res) => {
  const { title, pay, sector, type, location, desc, req: requirements, status } = req.body;
  if (!title || !pay) return res.status(400).json({ error: 'Title and pay are required.' });

  const jobs = readFile(JOBS_FILE);
  const job = {
    id:       uid(),
    title:    title.trim(),
    pay:      pay.trim(),
    sector:   sector || 'care',
    type:     type   || 'full-time',
    location: location || '',
    desc:     desc     || '',
    req:      requirements || '',
    status:   status || 'active',
    posted:   new Date().toISOString(),
    createdBy: req.user.email,
  };
  jobs.unshift(job);
  writeFile(JOBS_FILE, jobs);
  res.status(201).json(job);
});

/**
 * PUT /api/jobs/:id
 * Protected (any authenticated user) — update a job
 */
app.put('/api/jobs/:id', requireAuth, (req, res) => {
  const jobs = readFile(JOBS_FILE);
  const idx  = jobs.findIndex(j => j.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Job not found.' });
  jobs[idx] = { ...jobs[idx], ...req.body, id: jobs[idx].id, updatedAt: new Date().toISOString() };
  writeFile(JOBS_FILE, jobs);
  res.json(jobs[idx]);
});

/**
 * DELETE /api/jobs/:id
 * Protected (any authenticated user) — delete a job
 */
app.delete('/api/jobs/:id', requireAuth, (req, res) => {
  const jobs = readFile(JOBS_FILE);
  const filtered = jobs.filter(j => j.id !== req.params.id);
  if (filtered.length === jobs.length) return res.status(404).json({ error: 'Job not found.' });
  writeFile(JOBS_FILE, filtered);
  res.json({ success: true });
});

// ───────────────────────────────────────────────
// CONTACTS ROUTES
// ───────────────────────────────────────────────

/**
 * GET /api/contacts
 * Protected (any authenticated user) — list all enquiries
 */
app.get('/api/contacts', requireAuth, (req, res) => {
  res.json(readFile(CONTACTS_FILE));
});

/**
 * POST /api/contacts
 * Public — used by Netlify webhook or direct form submission
 * Accepts Netlify form payload and stores it
 */
app.post('/api/contacts', (req, res) => {
  const contacts = readFile(CONTACTS_FILE);
  const contact = {
    id:      uid(),
    name:    (req.body.name || req.body.first_name || '').trim(),
    email:   (req.body.email || '').trim(),
    phone:   (req.body.phone || '').trim(),
    type:    (req.body.enquiry_type || req.body.type || 'general').trim(),
    message: (req.body.message || req.body.notes || '').trim(),
    source:  req.body['form-name'] || 'api',
    status:  'new',
    date:    new Date().toISOString(),
  };
  contacts.unshift(contact);
  writeFile(CONTACTS_FILE, contacts);
  res.status(201).json({ success: true, id: contact.id });
});

/**
 * PUT /api/contacts/:id
 * Protected — mark read / update status
 */
app.put('/api/contacts/:id', requireAuth, (req, res) => {
  const contacts = readFile(CONTACTS_FILE);
  const idx = contacts.findIndex(c => c.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Contact not found.' });
  contacts[idx] = { ...contacts[idx], ...req.body, id: contacts[idx].id };
  writeFile(CONTACTS_FILE, contacts);
  res.json(contacts[idx]);
});

/**
 * DELETE /api/contacts/:id
 * Super Admin only
 */
app.delete('/api/contacts/:id', requireSuperAdmin, (req, res) => {
  const contacts = readFile(CONTACTS_FILE);
  const filtered = contacts.filter(c => c.id !== req.params.id);
  if (filtered.length === contacts.length) return res.status(404).json({ error: 'Contact not found.' });
  writeFile(CONTACTS_FILE, filtered);
  res.json({ success: true });
});

// ───────────────────────────────────────────────
// USER MANAGEMENT ROUTES (Super Admin only)
// ───────────────────────────────────────────────

/**
 * GET /api/users
 * Super Admin only — list all employee accounts (passwords NOT returned)
 */
app.get('/api/users', requireSuperAdmin, (req, res) => {
  const users = readFile(USERS_FILE).map(({ id, email, role, created }) => ({ id, email, role, created }));
  // Also include the Super Admin as a synthetic record
  const result = [
    { id: 'superadmin', email: SUPER_ADMIN_EMAIL, role: 'superadmin', created: null },
    ...users,
  ];
  res.json(result);
});

/**
 * POST /api/users
 * Super Admin only — create an employee account
 * Body: { email, password }
 */
app.post('/api/users', requireSuperAdmin, (req, res) => {
  const { email = '', password = '' } = req.body;
  if (!email || !email.includes('@')) return res.status(400).json({ error: 'Valid email required.' });
  if (!password || password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });

  const emailLc = email.trim().toLowerCase();

  // Block creating an account with Super Admin's email
  if (emailLc === SUPER_ADMIN_EMAIL.toLowerCase()) return res.status(409).json({ error: 'This email is reserved.' });

  const users = readFile(USERS_FILE);
  if (users.find(u => u.email.toLowerCase() === emailLc)) {
    return res.status(409).json({ error: 'An account with this email already exists.' });
  }

  const user = {
    id:       uid(),
    email:    emailLc,
    password: password, // NOTE: store hashed in production — see note below
    role:     'employee',
    created:  new Date().toISOString(),
  };
  users.push(user);
  writeFile(USERS_FILE, users);

  // Return without password
  const { password: _, ...safeUser } = user;
  res.status(201).json(safeUser);
});

/**
 * DELETE /api/users/:id
 * Super Admin only — delete an employee account
 */
app.delete('/api/users/:id', requireSuperAdmin, (req, res) => {
  if (req.params.id === 'superadmin') return res.status(403).json({ error: 'Cannot delete the Super Admin account.' });
  const users = readFile(USERS_FILE);
  const filtered = users.filter(u => u.id !== req.params.id);
  if (filtered.length === users.length) return res.status(404).json({ error: 'User not found.' });
  writeFile(USERS_FILE, filtered);
  res.json({ success: true });
});

// ───────────────────────────────────────────────
// NETLIFY WEBHOOK (optional)
// ───────────────────────────────────────────────
/**
 * POST /api/netlify-webhook
 * Netlify can POST form submissions here.
 * Configure in: Netlify Dashboard → Forms → your form → Notifications → Outgoing webhook
 * Set URL to: https://your-api.onrender.com/api/netlify-webhook
 */
app.post('/api/netlify-webhook', (req, res) => {
  const payload = req.body;
  const data = payload.data || payload;
  const contacts = readFile(CONTACTS_FILE);
  contacts.unshift({
    id:      uid(),
    name:    (data.name || data.first_name || '').trim(),
    email:   (data.email || '').trim(),
    phone:   (data.phone || '').trim(),
    type:    (data.enquiry_type || data.type || payload.form_name || 'general').trim(),
    message: (data.message || data.notes || '').trim(),
    source:  payload.form_name || 'netlify-webhook',
    status:  'new',
    date:    new Date().toISOString(),
  });
  writeFile(CONTACTS_FILE, contacts);
  res.json({ received: true });
});

// ───────────────────────────────────────────────
// CANDIDATE APPLICATIONS (from recruitment.html)
// ───────────────────────────────────────────────

/**
 * POST /api/applications
 * Public — stores a candidate application
 */
const APPS_FILE = path.join(DATA_DIR, 'applications.json');
app.post('/api/applications', (req, res) => {
  const apps = readFile(APPS_FILE);
  const app_entry = {
    id:           uid(),
    first_name:   (req.body.first_name || '').trim(),
    last_name:    (req.body.last_name  || '').trim(),
    email:        (req.body.email      || '').trim(),
    phone:        (req.body.phone      || '').trim(),
    sector:       (req.body.sector     || '').trim(),
    availability: (req.body.availability || '').trim(),
    notes:        (req.body.notes      || '').trim(),
    status:       'new',
    date:         new Date().toISOString(),
  };
  apps.unshift(app_entry);
  writeFile(APPS_FILE, apps);
  res.status(201).json({ success: true, id: app_entry.id });
});

app.get('/api/applications', requireAuth, (req, res) => {
  res.json(readFile(APPS_FILE));
});

// ───────────────────────────────────────────────
// 404 CATCH-ALL
// ───────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found.' });
});

// ───────────────────────────────────────────────
// ERROR HANDLER
// ───────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error.' });
});

// ───────────────────────────────────────────────
// START
// ───────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 Covenant Crest API running on port ${PORT}`);
  console.log(`   Super Admin: ${SUPER_ADMIN_EMAIL}`);
  console.log(`   Data directory: ${DATA_DIR}`);
  console.log(`   Allowed origin: ${ALLOWED_ORIGIN}`);
  console.log('\n📋 Endpoints:');
  console.log('   GET  /api/jobs              — public job listings');
  console.log('   POST /api/auth/login        — get JWT token');
  console.log('   GET  /api/contacts          — view enquiries (auth)');
  console.log('   GET  /api/users             — user list (super admin)');
  console.log('   POST /api/users             — create employee (super admin)');
  console.log('   POST /api/netlify-webhook   — Netlify form webhook\n');
});

/*
 * ===================================================================
 * PRODUCTION SECURITY NOTE
 * ===================================================================
 * This server stores passwords as plain text in a JSON file for
 * simplicity. Before going to production at scale, you should:
 *
 *   1. Hash passwords using bcrypt:
 *      npm install bcrypt
 *      const bcrypt = require('bcrypt');
 *      const hash = await bcrypt.hash(password, 10);
 *      const match = await bcrypt.compare(password, storedHash);
 *
 *   2. Move to a real database (e.g. PlanetScale, Supabase, MongoDB)
 *      if you expect more than a handful of users or jobs.
 *
 *   3. Set JWT_SECRET, SUPER_ADMIN_EMAIL, SUPER_ADMIN_PWD as
 *      environment variables on Render.com — NEVER hardcode them.
 *
 *   4. Enable HTTPS (Render.com does this automatically).
 * ===================================================================
 */

module.exports = app; // for testing
